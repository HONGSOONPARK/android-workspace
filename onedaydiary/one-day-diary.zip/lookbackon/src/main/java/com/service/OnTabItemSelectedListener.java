package com.service;

public interface OnTabItemSelectedListener {

    public void onTabSelected(int position);

}
